
class Item(object):
    "base class for all game items"

    def __init__(self, item_name: str, item_value: int, item_description: str) -> None:
        self.item_name: str = item_name
        self.item_value: int = item_value
        self.item_description: str = item_description

    def __str__(self) -> str:
        return f"\nitem name: {self.item_name}\nitem value: {str(self.item_value)}\nitem description: {self.item_description}\n"

    def get_item_name(self) -> str:
        return self.item_name

    def get_item_value(self) -> int:
        return self.item_value

    def get_item_description(self) -> str:
        return self.item_description

    def set_item_name(self, item_name: str) -> None:
        self.item_name: str = item_name

    def set_item_value(self, item_value: int) -> None:
        self.item_value: int = item_value

    def set_item_description(self, item_description: str) -> None:
        self.item_description: str = item_description
