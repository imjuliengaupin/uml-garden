
from item import Item


class Coin(Item):
    "base class for all game currency"

    def __init__(self, coin_color: str, coin_value: int) -> None:
        self.coin_color: str = coin_color
        self.coin_value: int = coin_value

        super().__init__(item_name=f"{self.coin_color} coin",
                         item_value=self.coin_value,
                         item_description=f"a round {self.coin_color} coin with a {str(self.coin_value)} stamped on the front")

    def get_coin_color(self) -> str:
        return self.coin_color

    def get_coin_value(self) -> int:
        return self.coin_value

    def set_coin_color(self, coin_color: str) -> None:
        self.coin_color: str = coin_color

    def set_coin_value(self, coin_value: int) -> None:
        self.coin_value: int = coin_value
